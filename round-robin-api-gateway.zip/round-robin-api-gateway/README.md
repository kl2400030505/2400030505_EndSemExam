# Round Robin Load Balancing using Spring Cloud Gateway

A small Maven multi-module demo containing:
- `eureka-server`: service registry on port 8761
- `driver-service`: REST service; run three instances on ports 8081, 8082 and 8083
- `api-gateway`: gateway on port 8080, forwarding `/drivers` to `lb://driver-service`

## Requirements
- JDK 17
- Maven 3.8+
- Internet connection for Maven to download dependencies

## Build
From this root folder:
```bash
mvn clean package
```

## Run (open separate terminals)

1. Eureka:
```bash
mvn -pl eureka-server spring-boot:run
```

2. Driver instance 1:
```bash
mvn -pl driver-service spring-boot:run
```

3. Driver instance 2:
```bash
mvn -pl driver-service spring-boot:run -Dspring-boot.run.arguments=--server.port=8082
```

4. Driver instance 3:
```bash
mvn -pl driver-service spring-boot:run -Dspring-boot.run.arguments=--server.port=8083
```

5. API Gateway:
```bash
mvn -pl api-gateway spring-boot:run
```

Open `http://localhost:8761` to see registered services. Send repeated GET requests to:
`http://localhost:8080/drivers`

The response includes the instance port so you can observe which instance handled each request.

## Notes
- This is a starter example, not a claim that it has been run in your local environment.
- Round-robin selection is the default strategy used by Spring Cloud LoadBalancer for this simple service setup.
- If your instructor gave you an existing repository, add these project files to that repository's required folder structure. Check its README and submission rules first.
